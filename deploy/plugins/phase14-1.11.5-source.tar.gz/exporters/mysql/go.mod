module github.com/Ray-ymq/GoPulse/exporters/mysql

go 1.26

require github.com/go-sql-driver/mysql v1.10.0

require filippo.io/edwards25519 v1.2.0 // indirect
