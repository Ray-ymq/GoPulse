#!/usr/bin/env bash
set -u

run_dir="$(cd "$(dirname "$0")" && pwd)"
root="$(cd "$run_dir/../.." && pwd)"
k6_bin="${K6_BIN:-$root/.run/tools/k6/0.56.0/linux-amd64/k6}"

if [ ! -x "$k6_bin" ]; then
  printf 'k6 binary is not executable: %s\n' "$k6_bin" >&2
  exit 1
fi
if [ ! -s "$run_dir/seed.json" ]; then
  printf 'seed file is missing: %s\n' "$run_dir/seed.json" >&2
  exit 1
fi

rm -f "$run_dir/monitor.stop"
start_time="$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ)"
printf '%s\n' "$start_time" > "$run_dir/start-time.txt"

"$k6_bin" run \
  --env "SEED_FILE=$run_dir/seed.json" \
  --env "BASE_URL=${BASE_URL:-https://localhost}" \
  --summary-export "$run_dir/summary.json" \
  --out "json=$run_dir/k6-samples.json" \
  "$run_dir/warmup.js" \
  > "$run_dir/k6.log" 2>&1 &
k6_pid=$!
printf '%s\n' "$k6_pid" > "$run_dir/k6.pid"

"$run_dir/monitor.sh" "$run_dir" "$k6_pid" > "$run_dir/monitor.log" 2>&1 &
monitor_pid=$!
printf '%s\n' "$monitor_pid" > "$run_dir/monitor.pid"

wait "$k6_pid"
k6_status=$?
if [ -f "$run_dir/fatal.stop" ]; then
  k6_status=2
fi
end_time="$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ)"
printf '%s\n' "$end_time" > "$run_dir/end-time.txt"
printf 'k6_exit_status=%s\n' "$k6_status" > "$run_dir/status.txt"

touch "$run_dir/monitor.stop"
wait "$monitor_pid" || true

exit "$k6_status"
