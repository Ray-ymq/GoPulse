#!/usr/bin/env bash
set -u

run_dir="$1"
k6_pid="$2"
root="$(cd "$(dirname "$0")/../.." && pwd)"
sample_seconds="${SAMPLE_SECONDS:-10}"

containers=(
  gopulse-api-1
  gopulse-elasticsearch-1
  gopulse-redis-1
  gopulse-mysql-1
  gopulse-indexer-1
  gopulse-rabbitmq-1
  gopulse-worker-1
)

resource_file="$run_dir/resources.csv"
health_file="$run_dir/health.csv"
es_file="$run_dir/elasticsearch.csv"
throttle_file="$run_dir/throttle.csv"
host_file="$run_dir/host.csv"
event_file="$run_dir/events.log"

printf '%s\n' 'timestamp,elapsed_s,k6_cpu_pct,k6_rss_mib,api_cpu_pct,api_mem_mib,es_cpu_pct,es_mem_mib,redis_cpu_pct,redis_mem_mib,mysql_cpu_pct,mysql_mem_mib,indexer_cpu_pct,indexer_mem_mib,rabbitmq_cpu_pct,rabbitmq_mem_mib,worker_cpu_pct,worker_mem_mib,container_restarts,oom_killed,health_ok,throttled_delta' > "$resource_file"
printf '%s\n' 'timestamp,api,elasticsearch,redis,mysql,indexer,rabbitmq,worker,web,api_restarts,es_restarts,redis_restarts,mysql_restarts,indexer_restarts,rabbitmq_restarts,worker_restarts,web_restarts,oom_killed' > "$health_file"
printf '%s\n' 'timestamp,es_cpu_pct,search_queue,search_rejected,heap_used_bytes,heap_max_bytes,mem_used_bytes,mem_max_bytes,redis_used_memory_bytes,redis_maxmemory_bytes,redis_policy' > "$es_file"
printf '%s\n' 'timestamp,api,indexer,worker,rabbitmq,elasticsearch,redis,mysql,total' > "$throttle_file"
printf '%s\n' 'timestamp,mem_total_mib,mem_used_mib,mem_available_mib,swap_total_mib,swap_used_mib' > "$host_file"

declare -A baseline_throttle
declare -A baseline_restarts
for container in "${containers[@]}"; do
  baseline_throttle["$container"]="$(docker exec "$container" sh -c "awk '\$1==\"nr_throttled\"{print \$2}' /sys/fs/cgroup/cpu.stat 2>/dev/null" 2>/dev/null || true)"
  [ -n "${baseline_throttle[$container]}" ] || baseline_throttle["$container"]=0
  baseline_restarts["$container"]="$(docker inspect -f '{{.RestartCount}}' "$container" 2>/dev/null || printf '0')"
done

to_mib() {
  awk -v value="$1" 'BEGIN {
    if (value == "" || value == "NA") { print "NA"; exit }
    unit=value
    sub(/^[0-9.]+/, "", unit)
    number=value
    sub(/[A-Za-z]+$/, "", number)
    if (unit == "B") factor=1/1048576
    else if (unit == "kB" || unit == "KB" || unit == "KiB") factor=1/1024
    else if (unit == "MB" || unit == "MiB") factor=1
    else if (unit == "GB" || unit == "GiB") factor=1024
    else factor=1
    printf "%.3f", number*factor
  }'
}

stats_value() {
  local container="$1"
  local field="$2"
  local line
  line="$(printf '%s\n' "$stats_snapshot" | awk -F '\t' -v n="$container" '$1==n{print; exit}')"
  if [ -z "$line" ]; then
    printf 'NA,NA'
    return
  fi
  local cpu memfield mem
  cpu="$(printf '%s\n' "$line" | awk -F '\t' '{gsub(/%/,"",$2); print $2}')"
  memfield="$(printf '%s\n' "$line" | cut -f3)"
  mem="$(printf '%s\n' "$memfield" | awk '{print $1}')"
  if [ "$field" = cpu ]; then
    printf '%s' "$cpu"
  else
    to_mib "$mem"
  fi
}

inspect_state() {
  local container="$1"
  docker inspect -f '{{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}} {{.RestartCount}} {{.State.OOMKilled}}' "$container" 2>/dev/null || printf 'missing unknown NA false'
}

throttle_value() {
  local container="$1"
  docker exec "$container" sh -c "awk '\$1==\"nr_throttled\"{print \$2}' /sys/fs/cgroup/cpu.stat 2>/dev/null" 2>/dev/null || true
}

es_query() {
  docker exec gopulse-elasticsearch-1 bash -c "$1" 2>/dev/null || true
}

start_epoch="$(date +%s)"
last_health=''

while [ ! -f "$run_dir/monitor.stop" ]; do
  now_iso="$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ)"
  elapsed="$(($(date +%s)-start_epoch))"

  k6_cpu='NA'
  k6_rss='NA'
  if kill -0 "$k6_pid" 2>/dev/null; then
    k6_cpu="$(ps -p "$k6_pid" -o %cpu= 2>/dev/null | awk '{print $1}')"
    k6_rss="$(ps -p "$k6_pid" -o rss= 2>/dev/null | awk '{printf "%.3f", $1/1024}')"
  fi

  declare -A cpu mem
  stats_snapshot="$(docker stats --no-stream --format '{{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}' "${containers[@]}" 2>/dev/null || true)"
  for pair in 'api gopulse-api-1' 'es gopulse-elasticsearch-1' 'redis gopulse-redis-1' 'mysql gopulse-mysql-1' 'indexer gopulse-indexer-1' 'rabbitmq gopulse-rabbitmq-1' 'worker gopulse-worker-1'; do
    key="${pair%% *}"
    container="${pair#* }"
    cpu["$key"]="$(stats_value "$container" cpu)"
    mem["$key"]="$(stats_value "$container" mem)"
  done

  total_throttle=0
  throttle_values=()
  for pair in 'api gopulse-api-1' 'indexer gopulse-indexer-1' 'worker gopulse-worker-1' 'rabbitmq gopulse-rabbitmq-1' 'es gopulse-elasticsearch-1' 'redis gopulse-redis-1' 'mysql gopulse-mysql-1'; do
    key="${pair%% *}"
    container="${pair#* }"
    current="$(throttle_value "$container")"
    [ -n "$current" ] || current=0
    delta=$((current - ${baseline_throttle[$container]:-0}))
    [ "$delta" -ge 0 ] || delta=0
    throttle_values+=("$delta")
    total_throttle=$((total_throttle + delta))
  done
  printf '%s\n' "$now_iso,${throttle_values[*]// /,},$total_throttle" >> "$throttle_file"

  states=()
  restart_values=()
  oom_count=0
  health_ok=1
  for service in api elasticsearch redis mysql indexer rabbitmq worker web; do
    state="$(inspect_state "gopulse-${service}-1")"
    read -r status health restarts oom <<< "$state"
    states+=("${health:-unknown}")
    restart_values+=("${restarts:-NA}")
    if [ "$health" != healthy ] && [ "$service" != web ]; then
      health_ok=0
    fi
    if [ "$oom" = true ]; then
      oom_count=$((oom_count + 1))
    fi
  done
  printf '%s\n' "$now_iso,${states[*]// /,},${restart_values[*]// /,},$oom_count" >> "$health_file"

  if [ "$health_ok" -ne 1 ] || [ "$oom_count" -gt 0 ]; then
    event="health_or_oom timestamp=$now_iso health_ok=$health_ok oom_killed=$oom_count"
    if [ "$event" != "$last_health" ]; then
      printf '%s\n' "$event" | tee -a "$event_file"
      last_health="$event"
    fi
  fi
  restart_changed=0
  for container in "${containers[@]}"; do
    current_restarts="$(docker inspect -f '{{.RestartCount}}' "$container" 2>/dev/null || printf '0')"
    if [ "${current_restarts:-0}" -gt "${baseline_restarts[$container]:-0}" ]; then
      restart_changed=1
    fi
  done
  if [ "$total_throttle" -gt 0 ]; then
    printf 'throttle timestamp=%s delta=%s\n' "$now_iso" "$total_throttle" >> "$event_file"
  fi

  if [ "$health_ok" -ne 1 ] || [ "$oom_count" -gt 0 ] || [ "$restart_changed" -ne 0 ]; then
    reason="health_ok=$health_ok oom_killed=$oom_count restart_changed=$restart_changed throttled_delta=$total_throttle"
    printf 'fatal timestamp=%s %s\n' "$now_iso" "$reason" | tee -a "$event_file"
    printf '%s\n' "$reason" > "$run_dir/fatal.stop"
    kill "$k6_pid" 2>/dev/null || true
    break
  fi

  es_cpu='NA'
  search_queue='NA'
  search_rejected='NA'
  heap_used='NA'
  heap_max='NA'
  mem_used='NA'
  mem_max='NA'
  es_json="$(es_query "curl -sS --max-time 3 http://127.0.0.1:9200/_nodes/stats/os,process,jvm,thread_pool,indices?filter_path=nodes.*.os.cpu.percent,nodes.*.jvm.mem.heap_used_in_bytes,nodes.*.jvm.mem.heap_max_in_bytes,nodes.*.thread_pool.search.queue,nodes.*.thread_pool.search.rejected,nodes.*.indices.indexing.index_total")"
  if [ -n "$es_json" ]; then
    es_cpu="$(printf '%s' "$es_json" | sed -n 's/.*"percent":\([0-9][0-9]*\).*/\1/p' | head -n 1)"
    search_queue="$(printf '%s' "$es_json" | sed -n 's/.*"search":{"queue":\([0-9][0-9]*\),"rejected":.*/\1/p' | head -n 1)"
    search_rejected="$(printf '%s' "$es_json" | sed -n 's/.*"search":{"queue":[0-9][0-9]*,"rejected":\([0-9][0-9]*\).*/\1/p' | head -n 1)"
    heap_used="$(printf '%s' "$es_json" | sed -n 's/.*"heap_used_in_bytes":\([0-9][0-9]*\).*/\1/p' | head -n 1)"
    heap_max="$(printf '%s' "$es_json" | sed -n 's/.*"heap_max_in_bytes":\([0-9][0-9]*\).*/\1/p' | head -n 1)"
  fi
  mem_used="$(docker exec gopulse-elasticsearch-1 sh -c 'cat /sys/fs/cgroup/memory.current 2>/dev/null' 2>/dev/null || true)"
  mem_max="$(docker exec gopulse-elasticsearch-1 sh -c 'cat /sys/fs/cgroup/memory.max 2>/dev/null' 2>/dev/null || true)"
  [ -n "$mem_used" ] || mem_used=NA
  [ -n "$mem_max" ] || mem_max=NA
  redis_info="$(docker exec -e REDISCLI_AUTH="${REDIS_PASSWORD:-gopulse-redis}" gopulse-redis-1 redis-cli INFO memory 2>/dev/null || true)"
  redis_used="$(printf '%s\n' "$redis_info" | sed -n 's/^used_memory:\([0-9][0-9]*\).*/\1/p')"
  redis_max="$(printf '%s\n' "$redis_info" | sed -n 's/^maxmemory:\([0-9][0-9]*\).*/\1/p')"
  redis_policy="$(printf '%s\n' "$redis_info" | sed -n 's/^maxmemory_policy:\(.*\)/\1/p')"
  printf '%s\n' "$now_iso,$es_cpu,$search_queue,$search_rejected,$heap_used,$heap_max,$mem_used,$mem_max,${redis_used:-NA},${redis_max:-NA},${redis_policy:-NA}" >> "$es_file"

  mem_values="$(free -m | awk '/^Mem:/{print $2,$3,$7}')"
  read -r host_mem_total host_mem_used host_mem_available <<< "$mem_values"
  swap_values="$(free -m | awk '/^Swap:/{print $2,$3}')"
  read -r host_swap_total host_swap_used <<< "$swap_values"
  printf '%s\n' "$now_iso,${host_mem_total:-NA},${host_mem_used:-NA},${host_mem_available:-NA},${host_swap_total:-NA},${host_swap_used:-NA}" >> "$host_file"

  printf '%s\n' "$now_iso,$elapsed,$k6_cpu,$k6_rss,${cpu[api]},${mem[api]},${cpu[es]},${mem[es]},${cpu[redis]},${mem[redis]},${cpu[mysql]},${mem[mysql]},${cpu[indexer]},${mem[indexer]},${cpu[rabbitmq]},${mem[rabbitmq]},${cpu[worker]},${mem[worker]},${restart_values[0]},$oom_count,$health_ok,$total_throttle" >> "$resource_file"

  sleep "$sample_seconds"
done
