#!/usr/bin/env python3
"""Create discard-marked Warm-up reports from k6 points and 10-second samples."""

import csv
import json
import math
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone


ENDPOINTS = ("timeline", "detail", "post_search", "user_search")
METRIC_TO_ENDPOINT = {f"{endpoint}_latency": endpoint for endpoint in ENDPOINTS}


def parse_time(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def percentile(values, fraction):
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return round(ordered[lower], 3)
    weight = position - lower
    return round(ordered[lower] + (ordered[upper] - ordered[lower]) * weight, 3)


def stats(values):
    if not values:
        return {"count": 0, "avg_ms": None, "p50": None, "p90": None, "p95": None, "p99": None, "max": None}
    return {
        "count": len(values),
        "avg_ms": round(sum(values) / len(values), 3),
        "p50": percentile(values, 0.50),
        "p90": percentile(values, 0.90),
        "p95": percentile(values, 0.95),
        "p99": percentile(values, 0.99),
        "max": round(max(values), 3),
    }


def read_points(path):
    points = []
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            data = item.get("data") or {}
            if item.get("type") != "Point" or "time" not in data:
                continue
            tags = data.get("tags") or {}
            if tags.get("phase") != "warmup":
                continue
            points.append({
                "metric": item.get("metric", ""),
                "time": parse_time(data["time"]),
                "value": float(data.get("value", 0)),
                "tags": tags,
            })
    return points


def read_csv(path):
    if not os.path.exists(path):
        return []
    with open(path, newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def float_or_none(value):
    if value in (None, "", "NA", "nan"):
        return None
    try:
        return float(value)
    except ValueError:
        return None


def resource_for(resources, timestamp):
    if not resources:
        return {}
    target = parse_time(timestamp)
    best = min(resources, key=lambda row: abs(parse_time(row["timestamp"]) - target))
    return best


def main():
    run_dir = os.path.abspath(sys.argv[1])
    raw_path = os.path.join(run_dir, "k6-samples.json")
    points = read_points(raw_path)
    latency_points = [point for point in points if point["metric"] == "http_req_duration"]
    endpoint_latency = defaultdict(list)
    endpoint_errors = defaultdict(int)
    endpoint_503 = defaultdict(int)
    endpoint_statuses = defaultdict(Counter)

    for point in points:
        endpoint = METRIC_TO_ENDPOINT.get(point["metric"])
        if endpoint:
            endpoint_latency[endpoint].append(point["value"])
        for name in ENDPOINTS:
            if point["metric"] == f"{name}_error_rate":
                endpoint_errors[name] += int(point["value"] > 0)
            elif point["metric"] == f"{name}_503_requests":
                endpoint_503[name] += int(point["value"])
        if point["metric"] == "http_req_duration":
            endpoint = point["tags"].get("endpoint")
            if endpoint in ENDPOINTS:
                status = point["tags"].get("status", "unknown")
                endpoint_statuses[endpoint][status] += 1

    for endpoint in ENDPOINTS:
        report = stats(endpoint_latency[endpoint])
        report.update({
            "schema_version": "gopulse.phase1.warmup.endpoint-report.v1",
            "phase": "warmup",
            "discard": True,
            "endpoint": endpoint,
            "error_count": endpoint_errors[endpoint],
            "error_rate": round(endpoint_errors[endpoint] / report["count"], 8) if report["count"] else None,
            "http_503_count": endpoint_503[endpoint],
            "http_503_rate": round(endpoint_503[endpoint] / report["count"], 8) if report["count"] else None,
            "status_counts": dict(endpoint_statuses[endpoint]),
        })
        os.makedirs(os.path.join(run_dir, "endpoint-reports"), exist_ok=True)
        with open(os.path.join(run_dir, "endpoint-reports", f"{endpoint}.json"), "w", encoding="utf-8") as handle:
            json.dump(report, handle, ensure_ascii=False, indent=2)
            handle.write("\n")

    resources = read_csv(os.path.join(run_dir, "resources.csv"))
    es_rows = read_csv(os.path.join(run_dir, "elasticsearch.csv"))
    if not latency_points:
        raise SystemExit("no warmup http_req_duration points found")
    start = min(point["time"] for point in latency_points)
    end = max(point["time"] for point in latency_points)
    bins = []
    cursor = start.replace(microsecond=(start.microsecond // 10_000_000) * 10_000_000)
    while cursor <= end:
        bins.append(cursor)
        cursor += timedelta(seconds=10)

    csv_path = os.path.join(run_dir, "metrics_10s.csv")
    fields = [
        "timestamp", "conc", "qps", "avg_ms", "p50", "p90", "p95", "p99",
        "err_rate", "503_rate", "timeline_p95", "detail_p95", "post_search_p95",
        "user_search_p95", "es_cpu", "es_mem", "redis_cpu", "redis_mem", "mysql_cpu",
        "mysql_mem", "api_cpu", "api_mem", "throttled_delta",
    ]
    with open(csv_path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for bin_start in bins:
            bin_end = bin_start + timedelta(seconds=10)
            window = [point for point in latency_points if bin_start <= point["time"] < bin_end]
            endpoint_window = {}
            for endpoint in ENDPOINTS:
                endpoint_window[endpoint] = [
                    point["value"] for point in points
                    if point["metric"] == f"{endpoint}_latency" and bin_start <= point["time"] < bin_end
                ]
            error_count = sum(
                int(point["value"] > 0) for point in points
                if point["metric"] in {f"{endpoint}_error_rate" for endpoint in ENDPOINTS}
                and bin_start <= point["time"] < bin_end
            )
            status_503 = sum(
                int(point["value"]) for point in points
                if point["metric"] in {f"{endpoint}_503_requests" for endpoint in ENDPOINTS}
                and bin_start <= point["time"] < bin_end
            )
            global_stats = stats([point["value"] for point in window])
            resource = resource_for(resources, bin_start.isoformat().replace("+00:00", "Z"))
            es = resource_for(es_rows, bin_start.isoformat().replace("+00:00", "Z"))
            row = {
                "timestamp": bin_start.isoformat().replace("+00:00", "Z"),
                "conc": 32,
                "qps": round(len(window) / 10, 3),
                "avg_ms": global_stats["avg_ms"],
                "p50": global_stats["p50"],
                "p90": global_stats["p90"],
                "p95": global_stats["p95"],
                "p99": global_stats["p99"],
                "err_rate": round(error_count / len(window), 8) if window else None,
                "503_rate": round(status_503 / len(window), 8) if window else None,
                "timeline_p95": stats(endpoint_window["timeline"])["p95"],
                "detail_p95": stats(endpoint_window["detail"])["p95"],
                "post_search_p95": stats(endpoint_window["post_search"])["p95"],
                "user_search_p95": stats(endpoint_window["user_search"])["p95"],
                "es_cpu": resource.get("es_cpu_pct", "NA"),
                "es_mem": resource.get("es_mem_mib", "NA"),
                "redis_cpu": resource.get("redis_cpu_pct", "NA"),
                "redis_mem": resource.get("redis_mem_mib", "NA"),
                "mysql_cpu": resource.get("mysql_cpu_pct", "NA"),
                "mysql_mem": resource.get("mysql_mem_mib", "NA"),
                "api_cpu": resource.get("api_cpu_pct", "NA"),
                "api_mem": resource.get("api_mem_mib", "NA"),
                "throttled_delta": resource.get("throttled_delta", "NA"),
            }
            writer.writerow(row)

    with open(os.path.join(run_dir, "endpoint-status-counts.json"), "w", encoding="utf-8") as handle:
        json.dump({endpoint: dict(endpoint_statuses[endpoint]) for endpoint in ENDPOINTS}, handle, indent=2)
        handle.write("\n")

    summary = {
        "schema_version": "gopulse.phase1.warmup.postprocess.v1",
        "phase": "warmup",
        "discard": True,
        "duration_seconds": (end - start).total_seconds(),
        "request_count": len(latency_points),
        "endpoint_reports": {endpoint: f"endpoint-reports/{endpoint}.json" for endpoint in ENDPOINTS},
        "metrics_10s": "metrics_10s.csv",
    }
    with open(os.path.join(run_dir, "postprocess-summary.json"), "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()
