import http from 'k6/http';
import { check } from 'k6';
import { Counter, Rate, Trend } from 'k6/metrics';

const seed = JSON.parse(open(__ENV.SEED_FILE));
const baseURL = __ENV.BASE_URL || seed.base_url;
const cookieName = __ENV.COOKIE_NAME || 'gopulse_session';
const searchTerm = seed.search_term;

const endpointNames = ['timeline', 'detail', 'post_search', 'user_search'];
const metrics = {};
for (const endpoint of endpointNames) {
  metrics[endpoint] = {
    requests: new Counter(`${endpoint}_requests`),
    errors: new Rate(`${endpoint}_error_rate`),
    latency: new Trend(`${endpoint}_latency`, true),
    statuses503: new Counter(`${endpoint}_503_requests`),
  };
}
const warmupErrors = new Rate('warmup_error_rate');
const warmup503 = new Counter('warmup_503_requests');

export const options = {
  scenarios: {
    warmup: {
      executor: 'constant-arrival-rate',
      rate: 200,
      timeUnit: '1s',
      duration: '10m',
      preAllocatedVUs: 32,
      maxVUs: 32,
      exec: 'mixedWorkload',
    },
  },
  insecureSkipTLSVerify: true,
  summaryTrendStats: ['avg', 'min', 'med', 'p(50)', 'p(90)', 'p(95)', 'p(99)', 'max'],
  tags: {
    phase: 'warmup',
    discard: 'true',
  },
};

function sessionHeaders(session, endpoint) {
  return {
    headers: {
      Cookie: `${cookieName}=${session}`,
      Accept: 'application/json',
    },
    tags: {
      phase: 'warmup',
      discard: 'true',
      endpoint,
    },
  };
}

function record(endpoint, response) {
  const failed = response.status < 200 || response.status >= 400;
  const endpointMetric = metrics[endpoint];
  endpointMetric.requests.add(1);
  endpointMetric.errors.add(failed ? 1 : 0);
  endpointMetric.latency.add(response.timings.duration);
  endpointMetric.statuses503.add(response.status === 503 ? 1 : 0);
  warmupErrors.add(failed ? 1 : 0);
  if (response.status === 503) {
    warmup503.add(1);
  }
  check(response, {
    [`${endpoint} status is 200`]: (res) => res.status === 200,
  });
}

export function setup() {
  if (!seed.sessions || seed.sessions.length !== seed.users.length) {
    throw new Error('seed sessions do not match seed users');
  }
  return { sessions: seed.sessions.map((entry) => entry.session), posts: seed.posts };
}

export function mixedWorkload(data) {
  const session = data.sessions[(__VU - 1) % data.sessions.length];
  const selector = ((__ITER + __VU) * 17) % 100;
  let endpoint;
  let path;

  if (selector < 40) {
    endpoint = 'timeline';
    path = '/api/v1/posts?limit=20';
  } else if (selector < 60) {
    endpoint = 'detail';
    const postID = data.posts[(__ITER + __VU) % data.posts.length];
    path = `/api/v1/posts/${postID}`;
  } else if (selector < 85) {
    endpoint = 'post_search';
    path = `/api/v1/search/posts?q=${encodeURIComponent(searchTerm)}&limit=20`;
  } else {
    endpoint = 'user_search';
    path = `/api/v1/search/users?q=${encodeURIComponent(searchTerm)}&limit=20`;
  }

  const response = http.get(`${baseURL}${path}`, sessionHeaders(session, endpoint));
  record(endpoint, response);
}
